package com.example.assessmentwebbrowser;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity extends AppCompatActivity {

EditText url_field;
ImageButton refrbtn, gobtn, micbtn ;
WebView webView;
ProgressBar progressBar;
BottomSheetDialog bottomSheetDialog;
LinearLayout history, historyExit;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListner
            =new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()){
                case R.id.navigation_home:
                    Intent intent =new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                    return true;

                case R.id.navigation_left:
                    onBackPressed();
                    return true;
                case R.id.navigation_right:
                    onForwardPressed();
                    return true;
                case R.id.dashboard:
                    bottomSheetDialog.show();


                    return true;
            }
            return false;
        }
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
       setSupportActionBar(toolbar);


        url_field =findViewById(R.id.url_field);
        refrbtn=findViewById(R.id.refrbtn);
        gobtn=findViewById(R.id.gobtn);
        webView=findViewById(R.id.webView);
        progressBar= findViewById(R.id.progressBar);
        url_field.setOnEditorActionListener(editorListner);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.google.co.nz");
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        progressBar.setProgress(100);
        micbtn=findViewById(R.id.micbtn);
        createBottomSheetDialogue();



        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }
        });

        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                progressBar.setProgress(newProgress);
            }

            @Override
            public void onReceivedIcon(WebView view, Bitmap icon) {
                super.onReceivedIcon(view, icon);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
            }
        });


        refrbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
            webView.reload();
            }
        });

        gobtn.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View v) {
                                         url_field = findViewById(R.id.url_field);
                                         String urlstr = url_field.getText().toString();

                                         if (!urlstr.startsWith("https://")){
                                             urlstr="https://"+urlstr;
                                         }
                                         webView.loadUrl(urlstr);
                                         webView.setWebViewClient(new WebViewClient() {

                                             @Override
                                             public void onPageStarted(WebView view, String url, Bitmap favicon) {
                                                 super.onPageStarted(view, url, favicon);
                                                 progressBar.setVisibility(View.VISIBLE);
                                                 url_field.setText(url);
                                             }

                                             @Override
                                             public void onPageFinished(WebView view, String url) {
                                                 super.onPageFinished(view, url);
                                                 progressBar.setVisibility(View.GONE);
                                             }
                                         });

                                         webView.loadUrl(urlstr);
                                         WebSettings webSettings = webView.getSettings();
                                         webSettings.setJavaScriptEnabled(true);
                                     }
                                 });


        BottomNavigationView navigation = (BottomNavigationView)findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListner);

    }

    private TextView.OnEditorActionListener editorListner = new TextView.OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            switch (actionId){
                case EditorInfo
                        .IME_ACTION_GO:
                    Toast.makeText(MainActivity.this, "Loading...", Toast.LENGTH_SHORT).show();
                String urlstr = url_field.getText().toString();
                if (!urlstr.startsWith("http://")){
                    urlstr= "http://"+urlstr;
                }
                webView.loadUrl(urlstr);
            }
            return false;
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.extendedmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.history:
            break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()){
            webView.goBack();
        } else
        {
            MainActivity.super.onBackPressed();
        }
    }

    public void onForwardPressed(){
        if (webView.canGoForward()){
            webView.goForward();
        }
        else {
            Toast.makeText(this, "Cant go forward" , Toast.LENGTH_SHORT).show();
        }
    }

    private void createBottomSheetDialogue(){
        if (bottomSheetDialog==null){
            View view= LayoutInflater.from(this).inflate(R.layout.bottom_sheet_dialogue,null);
//            history=view.findViewById(R.id.history);
//            historyExit=view.findViewById(R.id.historyExit);
            bottomSheetDialog=new BottomSheetDialog(this);
            bottomSheetDialog.setContentView(view);
        }
    }
}